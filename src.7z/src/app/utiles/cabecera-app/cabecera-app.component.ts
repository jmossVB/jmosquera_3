import { Component } from '@angular/core';

@Component({
  selector: 'app-cabecera-app',
  standalone: true,
  imports: [],
  templateUrl: './cabecera-app.component.html',
  styleUrl: './cabecera-app.component.css'
})
export class CabeceraAppComponent {

}
