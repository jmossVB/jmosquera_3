import { Component } from '@angular/core';

@Component({
  selector: 'app-carrusel-app',
  standalone: true,
  imports: [],
  templateUrl: './carrusel-app.component.html',
  styleUrl: './carrusel-app.component.css'
})
export class CarruselAppComponent {

}
