import { Component } from '@angular/core';

@Component({
  selector: 'app-pie-app',
  standalone: true,
  imports: [],
  templateUrl: './pie-app.component.html',
  styleUrl: './pie-app.component.css'
})
export class PieAppComponent {

}
