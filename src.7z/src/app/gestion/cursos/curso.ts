export class Curso {

    constructor(
        public id?:string, 
        public nombre?:string, 
        public horas?:number, 
        public creditos?:number, 
        public categoria?:string
    ){}
}
