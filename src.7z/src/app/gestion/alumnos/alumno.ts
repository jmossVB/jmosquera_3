
export class Alumno {
    constructor(
        public id?:string, 
        public nombres?:string, 
        public apellidos?:string, 
        public fechadenacimiento?:string, 
        public direccion?:string, 
        public correo?:string, 
        public telefono?:string
    ){}
}
