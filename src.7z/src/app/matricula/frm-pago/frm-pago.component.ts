import { Component } from '@angular/core';

@Component({
  selector: 'app-frm-pago',
  standalone: true,
  imports: [],
  templateUrl: './frm-pago.component.html',
  styleUrl: './frm-pago.component.css'
})
export class FrmPagoComponent {

}
