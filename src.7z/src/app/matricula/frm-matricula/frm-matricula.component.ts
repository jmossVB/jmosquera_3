import { Component } from '@angular/core';

@Component({
  selector: 'app-frm-matricula',
  standalone: true,
  imports: [],
  templateUrl: './frm-matricula.component.html',
  styleUrl: './frm-matricula.component.css'
})
export class FrmMatriculaComponent {

}
